# JARVIS Android App

This is the native Kotlin + Jetpack Compose Android Studio project.

## Build an installable APK
1. Download and extract `JARVIS-Android.zip`.
2. Open the `JARVIS-Android` folder in Android Studio.
3. Install Android SDK Platform 35 when prompted; use JDK 17.
4. Wait for Gradle sync.
5. Select **Build > Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Motorola Edge 50 Pro and install it. Android may ask you to allow installs from that source.

## Included
- Dark sci-fi JARVIS UI with pulsing cyan core
- User-initiated Hindi speech recognition and stop control
- Hindi text-to-speech
- Explicit flashlight toggle, Android Settings shortcut, and alarm intent
- Chat log and typed demo chat

## Important
This is a local demo starter, not a full cloud AI assistant. Smart model responses require a secure backend. No APK was compiled in this environment because Android SDK/Gradle build tools are not installed here. Hardware speech recognition, Hindi voice availability, and flashlight support depend on the device.
