# JARVIS — native Android starter

A Kotlin + Jetpack Compose dark sci-fi assistant UI with animated cyan core, conversation log, user-initiated speech recognition, Hindi TTS, explicit flashlight / Settings / alarm actions, and a modular AI backend seam.

## Open and run

1. Install Android Studio (a recent stable release) and Android SDK Platform 35.
2. Unzip this project and choose **Open** in Android Studio, selecting the `JARVIS-Android` folder.
3. Let Gradle sync. Use JDK 17 for Gradle if Android Studio asks.
4. Run on an Android 8.0+ device or emulator. Speech recognition availability depends on installed system services and network/device configuration.
5. Microphone permission is requested only when you tap **SPEAK**. Camera permission is requested only when you tap **Flashlight**. No continuous/background recording is implemented.

## Current behavior and honest status

- Speech input is one user-started recognition session, with a visible status and a **STOP LISTENING** button. Android's recognizer may return an error if no recognition service is installed or available.
- Hindi TTS is attempted using Android TextToSpeech; voice availability varies by device/language packs.
- Flashlight commands use `CameraManager` and report caught errors. Camera permission is needed by Android for torch access.
- Settings and alarm buttons launch Android system intents. The alarm UI is opened with 7:00 AM prefilled; the user must confirm/save it in the clock app.
- The included `LocalDemoBackend` is intentionally a local placeholder. It is not a real LLM, and the UI's voice and text demo paths return simple local responses.

## Connect a real AI backend securely

1. Create a small backend you control (for example, HTTPS endpoint on your server) that accepts a user message and returns a response.
2. Store the model-provider API key as a server-side environment secret. Never put a provider key in Kotlin source, `BuildConfig`, resources, or the APK; APK contents can be extracted.
3. Add authentication and rate limiting to your backend, validate request sizes, apply timeouts, and avoid logging sensitive user conversations. Use HTTPS.
4. Implement `AiBackend` in `MainActivity.kt` with a repository/client that calls your backend. Keep the base URL configurable for debug/release builds and do not expose provider credentials to the app.
5. Route both typed and recognized messages through the same coroutine-backed repository. This starter keeps the demo path synchronous to remain small; replace it with a lifecycle-aware coroutine and loading/error states when wiring your service.

## Notes

- Package: `com.example.jarvis`
- Min SDK: 26 (Android 8.0)
- Compile SDK: 35
- This project has not been built in an Android SDK environment in this workspace. Open it in Android Studio and run Gradle sync/build to verify against your installed SDK.
