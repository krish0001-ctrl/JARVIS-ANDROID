package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Cyan = Color(0xFF43E8FF)
private val Deep = Color(0xFF050B14)
private val Panel = Color(0xFF0D1A29)
private val Muted = Color(0xFF8AA5B8)

data class ChatLine(val from: String, val message: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var onRecognized: ((String) -> Unit)? = null
    private var onSpeechStatus: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisScreen(this) }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("hi", "IN")
    }

    fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    fun listen(onStatus: (String) -> Unit, onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onStatus("Speech recognition unavailable")
            return
        }
        stopListening()
        onSpeechStatus = onStatus
        onRecognized = onResult
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onStatus("Listening…") }
                override fun onBeginningOfSpeech() { onStatus("Hearing you…") }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { onStatus("Processing…") }
                override fun onError(error: Int) {
                    onStatus("Stopped (code $error)")
                    stopListening()
                }
                override fun onResults(results: Bundle?) {
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!phrase.isNullOrBlank()) onRecognized?.invoke(phrase)
                    onStatus("Idle")
                    stopListening()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            onStatus("Starting microphone…")
            recognizer.startListening(intent)
        }
    }

    fun stopListening() {
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    fun toggleFlashlight(enabled: Boolean): String {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return "Camera permission required first."
        }
        return try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "Is phone mein flash available nahi hai."
            manager.setTorchMode(cameraId, enabled)
            if (enabled) "Flashlight ON command sent." else "Flashlight OFF command sent."
        } catch (e: Exception) {
            "Flashlight control failed: ${e.localizedMessage ?: "device error"}"
        }
    }

    override fun onDestroy() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private interface AiBackend {
    suspend fun reply(userText: String): String
}

/** Swap this implementation for a call to your own authenticated backend. */
private class LocalDemoBackend : AiBackend {
    override suspend fun reply(userText: String): String {
        val q = userText.lowercase(Locale.ROOT)
        return when {
            "hello" in q || "hi" in q || "namaste" in q -> "Namaste! Main JARVIS hoon. Batao, main kya help karun?"
            "time" in q || "samay" in q -> "Main abhi local demo mode mein hoon. Exact time ke liye phone ka clock check karo."
            "jarvis" in q -> "Ji, main sun raha hoon. Aap apna command type ya bol sakte hain."
            else -> "Samajh gaya: “$userText”. Abhi AI backend configure nahi hai, isliye yeh demo response hai."
        }
    }
}

@Composable
private fun JarvisScreen(activity: MainActivity) {
    val context = activity as Context
    val backend = remember { LocalDemoBackend() }
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var micStatus by remember { mutableStateOf("MIC OFF · tap to speak") }
    var flashOn by remember { mutableStateOf(false) }
    var cameraPermissionPending by remember { mutableStateOf(false) }
    val chat = remember { mutableStateListOf(ChatLine("JARVIS", "Systems online. Namaste! Main kaise help kar sakta hoon?")) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            listening = true
            activity.listen({ micStatus = it }, { phrase ->
                listening = false
                micStatus = "MIC OFF · tap to speak"
                chat.add(ChatLine("YOU", phrase))
                val reply = when {
                    phrase.contains("settings", true) || phrase.contains("setting", true) -> {
                        runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                        "Settings kholne ki request bhej di."
                    }
                    else -> "Received: $phrase"
                }
                chat.add(ChatLine("JARVIS", reply))
                activity.speak(reply)
            })
        } else {
            listening = false
            micStatus = "Microphone permission denied"
        }
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val result = activity.toggleFlashlight(!flashOn)
            flashOn = !flashOn
            chat.add(ChatLine("JARVIS", result))
        } else {
            chat.add(ChatLine("JARVIS", "Flashlight use karne ke liye Camera permission zaroori hai."))
        }
    }

    val transition = rememberInfiniteTransition(label = "core")
    val pulse by transition.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1700), RepeatMode.Reverse), label = "pulse"
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Deep, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1928), Deep)))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("J.A.R.V.I.S", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("PERSONAL AI INTERFACE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                StatusPill(if (listening) "MIC ACTIVE" else "STANDBY", listening)
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.size(180.dp).scale(pulse).border(1.dp, Cyan.copy(alpha = .7f), CircleShape)
                    .padding(10.dp).border(2.dp, Cyan.copy(alpha = .45f), CircleShape)
                    .background(Color(0xFF081725), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("◉", color = Cyan, fontSize = 54.sp)
                    Text("NEURAL CORE", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text(if (listening) "LISTENING" else "ONLINE", color = Muted, fontSize = 9.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(micStatus, color = if (listening) Cyan else Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 10.dp, bottom = 12.dp)) {
                Button(
                    onClick = {
                        if (listening) {
                            activity.stopListening()
                            listening = false
                            micStatus = "MIC OFF · listening stopped"
                        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            listening = true
                            activity.listen({ micStatus = it }, { phrase ->
                                listening = false
                                micStatus = "MIC OFF · tap to speak"
                                chat.add(ChatLine("YOU", phrase))
                                val reply = "Aapne kaha: $phrase. AI replies ke liye backend configure karein."
                                chat.add(ChatLine("JARVIS", reply))
                                activity.speak(reply)
                            })
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (listening) Color(0xFF7B2635) else Color(0xFF12394A))
                ) { Text(if (listening) "■ STOP LISTENING" else "🎙 SPEAK") }
                OutlinedButton(onClick = { activity.speak("Namaste. Main JARVIS hoon.") }) { Text("TEST VOICE") }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("⚡ Flashlight", Modifier.weight(1f)) {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        val result = activity.toggleFlashlight(!flashOn)
                        flashOn = !flashOn
                        chat.add(ChatLine("JARVIS", result))
                    } else cameraPermission.launch(Manifest.permission.CAMERA)
                }
                ActionButton("⚙ Settings", Modifier.weight(1f)) {
                    runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                        .onSuccess { chat.add(ChatLine("JARVIS", "Settings open karne ki request bheji.")) }
                        .onFailure { chat.add(ChatLine("JARVIS", "Settings nahi khul sake: ${it.localizedMessage}")) }
                }
                ActionButton("⏰ Alarm", Modifier.weight(1f)) {
                    runCatching {
                        context.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm")
                            putExtra(AlarmClock.EXTRA_HOUR, 7)
                            putExtra(AlarmClock.EXTRA_MINUTES, 0)
                            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        })
                        chat.add(ChatLine("JARVIS", "Alarm screen open karne ki request bheji. Alarm save karna clock app mein confirm karein."))
                    }.onFailure { chat.add(ChatLine("JARVIS", "Alarm screen open nahi ho saki: ${it.localizedMessage}")) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("CONVERSATION LOG", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { chat.clear() }) { Text("CLEAR", color = Muted) }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().background(Panel.copy(alpha = .78f), RoundedCornerShape(14.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chat) { line ->
                    Column(Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = .12f), RoundedCornerShape(9.dp)).padding(10.dp)) {
                        Text(line.from, color = if (line.from == "YOU") Color(0xFFFFC66D) else Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(line.message, color = Color(0xFFE5F2FA), fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message JARVIS…", color = Muted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan, unfocusedBorderColor = Muted.copy(alpha = .5f),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )
                Button(onClick = {
                    val message = input.trim()
                    if (message.isNotEmpty()) {
                        chat.add(ChatLine("YOU", message))
                        val reply = when {
                            message.contains("alarm", true) -> "Alarm button dabakar Clock app mein alarm set karein."
                            message.contains("flash", true) -> "Flashlight ke liye upar Flashlight button use karein."
                            else -> "Demo mode: “$message”. Secure AI backend connect karne par smart replies aayenge."
                        }
                        chat.add(ChatLine("JARVIS", reply))
                        activity.speak(reply)
                        input = ""
                    }
                }) { Text("SEND") }
            }
            Text("LOCAL DEMO · NO BACKGROUND RECORDING", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
private fun StatusPill(label: String, active: Boolean) {
    Row(
        Modifier.border(1.dp, if (active) Cyan else Muted.copy(alpha = .4f), RoundedCornerShape(30.dp))
            .background(Panel, RoundedCornerShape(30.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(6.dp).background(if (active) Cyan else Muted, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(label, color = if (active) Cyan else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActionButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, modifier = modifier.height(44.dp),
        contentPadding = PaddingValues(horizontal = 5.dp),
        shape = RoundedCornerShape(10.dp)
    ) { Text(label, fontSize = 10.sp, maxLines = 1) }
}
